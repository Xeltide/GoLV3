package ca.bcit.comp2526.a2a;

public class RoCo {

    private int row;
    private int col;
    
    public RoCo(int row, int col) {
        this.row = row;
        this.col = col;
    }
    
    public int getRo() {
        return row;
    }
    
    public int getCo() {
        return col;
    }
}
