package ca.bcit.comp2526.a2a;
/**
 * Predefined entity types.
 * 
 * @author Joshua Abe
 * @version Nov.6th, 2016
 */
public enum EntityType {
    PLANT(),
    HERBIVORE(),
    CARNIVORE();
}
